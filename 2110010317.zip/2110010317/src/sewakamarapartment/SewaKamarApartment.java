/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sewakamarapartment;
import project.*;

/**
 *
 * @author W8
 */
public class SewaKamarApartment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Kamar
        Kamar objku = new Kamar();
        
        System.out.println("Info Kamar : " +objku.dataKamar("258 ","Deluxe ","ready ","Rp.550.000"));
        //AdminLogin
        AdminLogin objku2 = new AdminLogin();
        
        System.out.println("Login : " +objku2.dataAdminLogin("1234 ","admin"));
        //Pelanggan
        Pelanggan objku3 = new Pelanggan();
        
        System.out.println("Daftar Pelanggan : " +objku3.dataPelanggan("aori ","bjm ","081327"));
        //Penyewa
        Penyewa objku4= new Penyewa();
        
        System.out.println("Data Penyewa : " +objku4.dataPenyewa("onichan ","tokyo ","0892838 ","itadakimasu@gmail.com"));
        //Transaksi
        Transaksi objku5 = new Transaksi();
        
        System.out.println("Transakasi : " +objku5.dataTransaksi("258 ","Deluxe ","ready ","Rp.550.000"));
        //Laporan
         Laporan objku6 = new Laporan();
        
        System.out.println("Laporan : " +objku6.dataLaporan("258 ","Deluxe ","ready ","Rp.550.000"));
       
        
    }
        
}